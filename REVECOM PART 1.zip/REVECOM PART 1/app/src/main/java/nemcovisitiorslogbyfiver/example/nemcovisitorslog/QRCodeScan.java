package nemcovisitiorslogbyfiver.example.nemcovisitorslog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import eu.livotov.labs.android.camview.ScannerLiveView;
import eu.livotov.labs.android.camview.scanner.decoder.zxing.ZXDecoder;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.VIBRATE;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class QRCodeScan extends AppCompatActivity {

    private ScannerLiveView camera;
    private TextView scannedTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q_r_code_scan);
        scannedTV = findViewById(R.id.idTVscanned);
        camera = (ScannerLiveView) findViewById(R.id.camview);


        if (checkPermission()) {
            Toast.makeText(this, "Permission Granted..", Toast.LENGTH_SHORT).show();
        } else {
            requestPermission();
        }

        camera.setScannerViewEventListener(new ScannerLiveView.ScannerViewEventListener() {
            @Override
            public void onScannerStarted(ScannerLiveView scanner) {
                Toast.makeText(QRCodeScan.this, "Scanner Started", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onScannerStopped(ScannerLiveView scanner) {
                Toast.makeText(QRCodeScan.this, "Scanner Stopped", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onScannerError(Throwable err) {
                // method is called when scanner gives some error.
                Toast.makeText(QRCodeScan.this, "Scanner Error: " + err.getMessage(), Toast.LENGTH_SHORT).show();
            }

            private boolean isQRCodeScanned = false;

            @Override
            public void onCodeScanned(String data) {
                if (!isQRCodeScanned) {
                    if (data.length() == 6 && (data.charAt(0) == '1' || data.charAt(0) == '3' || data.charAt(0) == '5')) {
                        scannedTV.setText(data);
                        DataSaveToSharedPref(data);
                        isQRCodeScanned = true;
                        Intent intent = new Intent(QRCodeScan.this, commenter.class);
                    } else {
                        Toast.makeText(QRCodeScan.this, "Invalid QR", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(QRCodeScan.this, MainActivity.class);
                        startActivity(intent);
                    }
                }
            }


        });
    }

    private void DataSaveToSharedPref(String data) {
        for (Fav fav : MainActivity.courseModalArrayList) {
            if (fav.getData().equals(data)) {
                Toast.makeText(this, "Data already stored", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(QRCodeScan.this, MainActivity.class);
                startActivity(intent);
                return;
            }
        }

        MainActivity.courseModalArrayList.add(new Fav(data));
        MainActivity.adapter.notifyItemInserted(MainActivity.courseModalArrayList.size());

        // check if the data already exists in the shared preferences
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("courses", null);
        Type type = new TypeToken<ArrayList<Fav>>() {}.getType();
        ArrayList<Fav> favList = gson.fromJson(json, type);
        if (favList != null) {
            for (Fav fav : favList) {
                if (fav.getData().equals(data)) {
                    Toast.makeText(this, "Data already stored", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(QRCodeScan.this, MainActivity.class);
                    startActivity(intent);
                    return;

                }
            }
        }
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String jsonUpdated = gson.toJson(MainActivity.courseModalArrayList);
        editor.putString("courses", jsonUpdated);
        editor.apply();
        Toast.makeText(this, "Data Saved Success", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(QRCodeScan.this, commenter.class);
        startActivity(intent);
    }


    @Override
    protected void onResume() {
        super.onResume();
        ZXDecoder decoder = new ZXDecoder();
        decoder.setScanAreaPercent(0.8);
        camera.setDecoder(decoder);
        camera.startScanner();
    }

    @Override
    protected void onPause() {
        camera.stopScanner();
        super.onPause();
    }
    private boolean checkPermission() {
        int camera_permission = ContextCompat.checkSelfPermission(getApplicationContext(), CAMERA);
        int vibrate_permission = ContextCompat.checkSelfPermission(getApplicationContext(), VIBRATE);
        return camera_permission == PackageManager.PERMISSION_GRANTED && vibrate_permission == PackageManager.PERMISSION_GRANTED;
    }
    private void requestPermission() {
        int PERMISSION_REQUEST_CODE = 200;
        ActivityCompat.requestPermissions(this, new String[]{CAMERA, VIBRATE}, PERMISSION_REQUEST_CODE);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            boolean cameraaccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
            boolean vibrateaccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;
            if (cameraaccepted && vibrateaccepted) {
                Toast.makeText(this, "Permission granted..", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denined \n You cannot use app without providing permission", Toast.LENGTH_SHORT).show();
            }
        }
    }
}