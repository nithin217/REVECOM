package nemcovisitiorslogbyfiver.example.nemcovisitorslog;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class commenter extends AppCompatActivity {
    private EditText mobileET, nameET, commentET;
    private RatingBar ratingBar;
    private Button submitBtn;
    private ArrayList<Comment> commentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comment_page);
        mobileET = findViewById(R.id.editTextPhone);
        nameET = findViewById(R.id.editTextTextPersonName);
        commentET = findViewById(R.id.editTextTextMultiLine);
        ratingBar = findViewById(R.id.ratingBar);
        submitBtn = findViewById(R.id.button2);

        SharedPreferences sharedPreferences = getSharedPreferences("comments", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("commentList", null);
        if (json != null) {
            commentList = gson.fromJson(json, ArrayList.class);
        } else {
            commentList = new ArrayList<>();
        }

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phno = mobileET.getText().toString();
                String name = nameET.getText().toString();
                String comment = commentET.getText().toString();
                float rating = ratingBar.getRating();
                Comment newComment = new Comment(comment);
                commentList.add(newComment);
                SharedPreferences sharedPreferences = getSharedPreferences("comments", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                Gson gson = new Gson();
                String json = gson.toJson(commentList);
                editor.putString("commentList", json);
                editor.apply();
                Toast.makeText(commenter.this, "Comment submitted successfully", Toast.LENGTH_SHORT).show();
                Intent intentscan = new Intent(commenter.this,MainActivity.class);
                startActivity(intentscan);

            }
        });
    }
}
