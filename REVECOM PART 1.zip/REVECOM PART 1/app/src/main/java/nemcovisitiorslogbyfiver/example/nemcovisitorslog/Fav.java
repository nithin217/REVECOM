package nemcovisitiorslogbyfiver.example.nemcovisitorslog;

class Fav {

    private String name;

    Fav(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getData() {return name;}
}

