package nemcovisitiorslogbyfiver.example.nemcovisitorslog;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.ArrayList;

public class DisplayComment extends RecyclerView.Adapter<DisplayComment.ViewHolder2> {
    private ArrayList<Comment> pleasedisplay = new ArrayList<>();
    private Context context;
    public DisplayComment(ArrayList<Comment> pleasedisplay, Context context) {
        this.pleasedisplay = pleasedisplay;
        this.context = context;
    }

    @NonNull
    @Override
    public DisplayComment.ViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.save_layout1, parent, false);
        return new ViewHolder2(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder2 holder, @SuppressLint("RecyclerView") int position) {
        Comment modal = pleasedisplay.get(position);
        holder.details.setText(modal.getComment());


        holder.delte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.pleasedisplay.remove(position);
                notifyItemRemoved(position);



                SharedPreferences preferences = context.getSharedPreferences("shared preferences", Context.MODE_PRIVATE);
                SharedPreferences.Editor mEditor = preferences.edit();
                Gson gson = new Gson();

                String jsonString = gson.toJson(pleasedisplay);
                mEditor.putString("courses", jsonString);
                mEditor.apply();
            }
        });
    }


    @Override
    public int getItemCount() {
        return pleasedisplay.size();
    }

    public class ViewHolder2 extends RecyclerView.ViewHolder {
        private TextView details;
        private ImageView delte;
        public ViewHolder2(@NonNull View itemView) {
            super(itemView);
            details = itemView.findViewById(R.id.fav_user_details);
            delte = itemView.findViewById(R.id.fav_user_delete);
        }
    }
}