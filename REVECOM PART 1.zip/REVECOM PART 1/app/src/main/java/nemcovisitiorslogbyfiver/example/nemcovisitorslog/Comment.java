package nemcovisitiorslogbyfiver.example.nemcovisitorslog;

class Comment{

    private String comment;

    Comment(String comment) {
        this.comment = comment;
    }

    public String getComment() {
        return comment;
    }

    public String getData1() {return comment;}
}

