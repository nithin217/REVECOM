package nemcovisitiorslogbyfiver.example.nemcovisitorslog;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ImageView scan,save,commentdisp;
    static NotesAdapter adapter;
    static DisplayComment adapter2;
    static ArrayList<Fav> courseModalArrayList;
    static ArrayList<Comment> pleasedisplay;

    static SharedPreferences sharedPreferences, sharedPreferences2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        scan = findViewById(R.id.scan_image);
        save = findViewById(R.id.save_image);
        commentdisp = findViewById(R.id.commentdisp);
        sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);


        Gson gson = new Gson();

        String json = sharedPreferences.getString("courses", null);
        String json2=sharedPreferences.getString("courses",null);
        Type type = new TypeToken<ArrayList<Fav>>() {}.getType();
        courseModalArrayList = gson.fromJson(json, type);
        pleasedisplay = gson.fromJson(json2,type);
        if (courseModalArrayList == null) {
            courseModalArrayList = new ArrayList<>();
        }
        if(pleasedisplay == null){
            pleasedisplay = new ArrayList<>();
        }
        adapter = new NotesAdapter(courseModalArrayList, MainActivity.this);
        adapter2= new DisplayComment(pleasedisplay,MainActivity.this);
        scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentscan = new Intent(MainActivity.this,QRCodeScan.class);
                startActivity(intentscan);
            }
        });
        save.setOnClickListener(v -> {
            Intent intentscan = new Intent(MainActivity.this,ResultShow.class);
            startActivity(intentscan);
        });
        commentdisp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentscan = new Intent(MainActivity.this,CommentShower.class);
                startActivity(intentscan);
            }
        });

    }
}